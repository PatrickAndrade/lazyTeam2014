// Copyright (C) 2014 - LGG EPFL

#include <iostream>
#include <sstream>
#include "common.h"

#include "vshader.h"
#include "fshader.h"
#include "gshader.h"

using namespace std;
using namespace opengp;

const unsigned int nbV = 10000;

/// Shader program 
GLuint programID;

void update_matrix_stack(const mat4& model){
    /// Define projection matrix (camera intrinsics)
    static mat4 projection = Eigen::perspective(45.0f, 4.0f/3.0f, 0.1f, 10.0f);
    GLuint projection_id = glGetUniformLocation(programID, "projection");
    glUniformMatrix4fv(projection_id, ONE, DONT_TRANSPOSE, projection.data());
 
    /// Define the view matrix (camera extrinsics)
    vec3 cam_pos(0.0f, 0.0f, 2.5f);
    vec3 cam_look(0.0f, 0.0f, 0.0f);
    vec3 cam_up(0.0f, 1.0f, 0.0f);
    static mat4 view = Eigen::lookAt(cam_pos, cam_look, cam_up);
 
    /// Assemble the "Model View" matrix
    static mat4 model_view;
    model_view = view * model;
    GLuint model_view_id = glGetUniformLocation(programID, "model_view");
    glUniformMatrix4fv(model_view_id, ONE, DONT_TRANSPOSE, model_view.data());
}

void init() {
    ///Generate vertices
    std::vector<vec3> vertices(nbV);
    for(unsigned int i=0; i < nbV; ++i) {
        vec3 vertex(0.0, 0.0, 0.0);
        vertex += vec3(0.1 + static_cast<float>(i)*0.8/static_cast<float>(nbV), 0.0, 0.0);
        vertex = Eigen::AngleAxisf((10.0*i*M_PI)/static_cast<float>(nbV), vec3::UnitZ()).toRotationMatrix()*vertex;
        vertices[i] = vertex;
    }

    /// Vertex Array
    GLuint VertexArrayID;
    glGenVertexArrays(ONE, &VertexArrayID);
    glBindVertexArray(VertexArrayID);

    /// Vertex Buffer
    GLuint vertexbuffer;
    glGenBuffers(ONE, &vertexbuffer);
    glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer);
    glBufferData(GL_ARRAY_BUFFER, nbV*sizeof(vec3), &vertices[0], GL_STATIC_DRAW);

    /// Compile Shaders
    programID = compile_shaders(vshader, fshader, gshader);
    if(!programID) exit(EXIT_FAILURE);
    glUseProgram(programID);

    /// Vertex Attribute ID for Positions
    GLuint position = glGetAttribLocation(programID, "position");
    const int NUM_ELS = 3; /// floats per each vertex "position"
    glEnableVertexAttribArray(position);
    glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer);
    glVertexAttribPointer(position, NUM_ELS, GL_FLOAT, DONT_NORMALIZE, ZERO_STRIDE, ZERO_BUFFER_OFFSET);

    /// Initialize the matrix stack
    update_matrix_stack(mat4::Identity());

    /// OpenGL parameters
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_MULTISAMPLE);
}

void display() {
    static float tick = 0.0f;
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    /// >>>>>>>>>> TODO >>>>>>>>>>>
    /// Ex1:
    /// Pass the variable tick as uniform in order to access it in the vertex shader.
    /// <<<<<<<<<< TODO <<<<<<<<<<<

	int loc = glGetUniformLocation(programID, "tick");
	glUniform1f(loc, tick);

    ///<<<<<<<<<<<<<<<<<<<<<<<<<<<
    tick += 0.01f;
    glDrawArrays(GL_POINTS, 0, nbV);
}

int main(int, char**) {
    glfwInitWindowSize(640, 480);
    glfwCreateWindow("hw4: Spiral");
    glfwDisplayFunc(display);
    init();
    glfwTrackball(update_matrix_stack);
    glfwMainLoop();
    return EXIT_SUCCESS;    
}
