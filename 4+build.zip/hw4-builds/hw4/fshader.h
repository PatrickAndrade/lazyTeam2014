/* Generated file, DO NOT edit! */

static char const* const fshader = 
   "// Copyright (C) 2014 - LGG EPFL\n"
   "#version 330 core\n"
   "in vec3 color_g;\n"
   "in float si;\n"
   "out vec3 color;\n"
   "uniform float tick;\n"
   "void main() {\n"
   "    ///>>>>>>>>>> TODO >>>>>>>>>>>\n"
   "    /// Ex3:\n"
   "    /// Add an offset to the color_g variable\n"
   "    /// using si = tick x ||position||.\n"
   "    ///<<<<<<<<<< TODO <<<<<<<<<<<\n"
   "    color = color_g + (0.5 + 0.5 * vec3(sin(0.1 * si), sin(0.2 * si), sin(0.3 * si)));\n"
   "}\n"
   ;
