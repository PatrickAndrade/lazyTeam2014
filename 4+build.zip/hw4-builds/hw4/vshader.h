/* Generated file, DO NOT edit! */

static char const* const vshader = 
   "// Copyright (C) 2014 - LGG EPFL\n"
   "#version 330 core\n"
   "in vec3 position;\n"
   "out float _si[1];\n"
   "uniform float tick;\n"
   "void main() {\n"
   "    ///>>>>>>>>>> TODO >>>>>>>>>>>\n"
   "    /// Ex1:\n"
   "    /// Displace the z coordinate using the tick variable\n"
   "    /// defined in the \"display\" function\n"
   "    ///<<<<<<<<<< TODO <<<<<<<<<<<\n"
   "    \n"
   "    _si[0] = (tick * length(position));\n"
   "	\n"
   "    gl_Position = vec4(position.x, position.y, 0.5 * sin(tick * length(position)), 1.0);\n"
   "}\n"
   ;
